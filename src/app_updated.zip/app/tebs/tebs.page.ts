import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tebs',
  templateUrl: './tebs.page.html',
  styleUrls: ['./tebs.page.scss'],
})
export class TebsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
