const config ={
    apiKey: "AIzaSyD9QoB3sfOVL0B0E5wtVQ_cAl1VTCSNhmY",
    authDomain: "edutalk-ff881.firebaseapp.com",
    databaseURL: "https://edutalk-ff881.firebaseio.com",
    projectId: "edutalk-ff881",
    storageBucket: "edutalk-ff881.appspot.com",
    messagingSenderId: "396035353053",
    appId: "1:396035353053:android:b7f5d95730fa0ba6e02e34"
    
}
export default config