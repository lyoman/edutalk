import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { ChatPagePage } from './chat-page.page';

// import {AutosizeModule} from 'ngx-autosize';



const routes: Routes = [
  {
    path: '',
    component: ChatPagePage,
      }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
declarations: [ChatPagePage]
})
export class ChatPagePageModule {}
