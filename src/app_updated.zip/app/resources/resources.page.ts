import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resources',
  templateUrl: './resources.page.html',
  styleUrls: ['./resources.page.scss'],
})
export class ResourcesPage implements OnInit {

  document() {

  }
  audios() {

  }
  contact() {

  }
  camera() {

  }
  gallery() {

  }

  constructor() { }


  ngOnInit() {
  }

}
